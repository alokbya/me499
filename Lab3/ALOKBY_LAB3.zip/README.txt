Import the following modules to run lab3.py:

import matplotlib.pyplot as plt
import numpy as np 
from math import pi
import random
import msd
import time